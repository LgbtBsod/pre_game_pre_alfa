


artifacts = {'Brave Heart':{'stats':{'health':0.2,'strength':0.2,
'speed':0.2,'agility':0.2,'magic':0.2,
'energy':0.2,'stamina':0.2,'hp_regen':0.2,
'crit_chance':10,'crit_rate':50},
'subscribe':'don\'t regret','effect':{'name':'brave','stats':{'strength':0.3},'duration':20,'cooldown':20}},
            #'Witch Bane':{'stats':{'energy':'20%','magic':'25%'},'subscribe':'don\'t regret','effect':'Punishment'},
            #'Dad\'s Clock':{'stats':{'health':'50%'},'subscribe':'with love','effect':'1'},
            #'Boot\'s of speed':{'stats':{'agility':'20%'},'subscribe':'what ?','effect':'1'},
            


}
